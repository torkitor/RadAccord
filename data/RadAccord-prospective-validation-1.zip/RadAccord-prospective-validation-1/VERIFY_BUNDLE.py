"""Verify every byte in the derived-evidence bundle; standard library only."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import sys

root = Path(__file__).resolve().parent
try:
    expected = {}
    for line in (root/'MANIFEST.sha256').read_text(encoding='utf-8').splitlines():
        checksum, relative = line.split('  ', 1)
        parts = PurePosixPath(relative)
        if (not re.fullmatch('[0-9a-f]{64}', checksum) or parts.is_absolute() or
                '..' in parts.parts or '\\' in relative or relative in expected):
            raise ValueError('Invalid manifest entry.')
        expected[relative] = checksum
    actual = {path.relative_to(root).as_posix() for path in root.rglob('*') if path.is_file()
              and path.relative_to(root).parts[0] not in ('outputs', '__pycache__')
              and '__pycache__' not in path.relative_to(root).parts
              and path.name != 'MANIFEST.sha256'}
    if actual != set(expected):
        raise ValueError('Bundle file set differs from the manifest.')
    for relative, checksum in expected.items():
        path = root/relative
        if path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != checksum:
            raise ValueError('A bundle payload differs.')
    print(json.dumps({'status': 'passed', 'payload_files': len(expected)}))
except Exception as error:
    print(json.dumps({'status': 'failed', 'reason_code': 'bundle_integrity_failed',
                      'exception_type': type(error).__name__}))
    sys.exit(1)
