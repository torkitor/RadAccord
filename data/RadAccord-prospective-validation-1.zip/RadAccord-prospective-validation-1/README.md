# RadAccord prospective validation: immutable derived evidence

This archive preserves the 70 exact sources in the public `validation-plan-1.3.0rc1`
freeze, its publication record, selection and crop-verification provenance,
realized operational plans, four first-execution ledgers and the prespecified
aggregate. It is an author-run computational evaluation on previously unused
public Heart MRI and Lung CT volumes. It is not independent-user validation or a
clinical-outcome study. Uncertainty, unsupported operations and failures remain
in their original denominators; an unchanged native output is not a correctness
or clinical-validity certificate.

`EVIDENCE_INDEX.json` identifies the actual observed counts and hashes. Clinical
images, cropped images, private input manifests, raw native logs and author
contact information are excluded. The source collection attribution and licence
are retained under `protocol/sources/heldout_clinical`; Apache-2.0 applies to the
RadAccord software. The complete software distribution and historical experiments
remain available in the main repository. This focused archive is sufficient for
the prospective source verification and aggregation commands below; it does not
include every dataset needed by unrelated historical test suites.

## Verify and replay

Extract the archive into a fresh directory. Python 3.10 or later can verify its
manifest without installing any package:

```sh
python -B VERIFY_BUNDLE.py
python -B scripts/verify_prospective_freeze.py
```

For aggregation replay, use a compatible isolated environment and the supplied
small dependency list. The replay imports the frozen study helpers but never
calls a native extractor or reads source images. PyRadiomics, MIRP and clinical
data downloads are unnecessary for this replay.

```sh
python -m pip install -r requirements-replay.txt
python -B REPLAY_PROSPECTIVE.py
```

The wrapper independently verifies the payload manifest and the 70-file freeze,
runs the archived `build_prospective_plans.py summarize` command and requires the
new aggregate to be byte-identical to `results/prospective_aggregate.json`.
Outputs are written under `outputs/`; use a fresh output filename for another
replay. Neither the source files nor the retained results are overwritten.

An independently implemented, standard-library-only accounting audit is included
under `qa/`. It checks JSON/JSONL, crop receipts, identifiers, denominators, states,
warmup and paired arithmetic; it does not reconstruct private native feature
values or provide an external-operator evaluation. Its original receipt is
retained. To repeat it from the archive root:

```sh
python -B qa/independent_prospective_audit.py --repo . --output outputs/repeated_independent_audit.json
```

Its recomputed aggregate tables should agree; the audit receipt itself need not
be byte-identical because its evidence collection is a separate QA record. All
public numerical analysis is replayed from the original frozen implementation.
No result is inferred from this README or an archive badge.
