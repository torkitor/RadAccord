"""Replay the frozen aggregation; no images or native extractor are run."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, default=root/'outputs/replayed_aggregate.json')
args = parser.parse_args()
def run(arguments):
    result = subprocess.run([sys.executable, '-B', *arguments], cwd=root,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode:
        raise RuntimeError('An archived verification/replay command failed.')
    return json.loads(result.stdout)
try:
    if args.output.exists():
        raise ValueError('Replay output must be new.')
    manifest = run(['VERIFY_BUNDLE.py'])
    freeze = run(['scripts/verify_prospective_freeze.py'])
    if freeze['files_verified'] != 70:
        raise ValueError('The prospective source census differs.')
    command = ['scripts/build_prospective_plans.py', 'summarize']
    for mode in ('coverage', 'timing'):
        command += ['--plan', 'protocol/prospective_operational/'+mode+'_plan.json']
    for mode in ('coverage', 'timing'):
        for engine in ('pyradiomics', 'mirp'):
            command += ['--run', 'results/prospective_'+mode+'/'+engine]
    command += ['--output', str(args.output)]
    run(command)
    expected = root/'results/prospective_aggregate.json'
    digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
    if digest(args.output) != digest(expected):
        raise ValueError('Replayed aggregate differs from the retained aggregate.')
    print(json.dumps({'status': 'passed', 'frozen_sources': 70,
                      'payload_files': manifest['payload_files'],
                      'aggregate_sha256': digest(args.output), 'byte_identical': True}))
except Exception as error:
    print(json.dumps({'status': 'failed', 'reason_code': 'prospective_replay_failed',
                      'exception_type': type(error).__name__}))
    sys.exit(1)
