La contabilidad independiente coincide con los resultados y el agregado preespecificado; conserva exclusiones, incertidumbre y fallos.

Independent implementation of record accounting and arithmetic, using Python standard library only. No image reading, producer execution, independent recovery of private native feature values, or external-user validation.
