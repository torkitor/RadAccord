"""Independent result accounting using only JSON/JSONL and the Python stdlib.

No RadAccord module, producer, benchmark, builder, NumPy or image reader is
imported. This checks recorded evidence and arithmetic; it does not independently
re-extract private native values or constitute an external-operator validation.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import itertools
import json
import math
from pathlib import Path
import re
import statistics
import sys

BASE = Path(__file__).resolve().parents[1]
TASKS = {'Task02_Heart': 'mr', 'Task06_Lung': 'ct'}
ENGINES = ('pyradiomics', 'mirp')
MODES = ('coverage', 'timing')
STATES = ('satisfied', 'violated', 'indeterminate', 'unavailable')
METRICS = ('baseline_seconds', 'audited_seconds', 'absolute_overhead_seconds',
           'paired_log_ratio', 'pair_lifetime_peak_bytes')


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    allow_nan=False).encode()).hexdigest()


def unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON object key.')
        result[key] = value
    return result


def json_read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'), object_pairs_hook=unique_pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError('Nonfinite JSON value.')))


def json_lines(path):
    return [json.loads(line, object_pairs_hook=unique_pairs,
                       parse_constant=lambda _: (_ for _ in ()).throw(ValueError('Nonfinite JSON value.')))
            for line in Path(path).read_text(encoding='utf-8').splitlines() if line.strip()]


def quantile(values, probability):
    """Linear rank interpolation (R7), independently of NumPy percentile."""
    numbers = sorted(values)
    position = (len(numbers)-1)*probability
    lower, upper = math.floor(position), math.ceil(position)
    return numbers[lower]+(numbers[upper]-numbers[lower])*(position-lower)


def describe(values, include_range=False):
    values = [float(value) for value in values if value is not None and math.isfinite(value)]
    result = {'n': len(values), 'median': statistics.median(values) if values else None,
              'q1': quantile(values, .25) if values else None, 'q3': quantile(values, .75) if values else None}
    if include_range:
        result.update(minimum=min(values) if values else None, maximum=max(values) if values else None)
    return result


def slot_key(row):
    return row['mode'], row['engine'], row['input_id'], row['workflow'], row['repeat']


def expected_slots(plan, engine):
    result = []
    for source, workflow in itertools.product(plan['inputs'], plan['workflows']):
        if source['modality'] not in workflow['modalities'] or engine not in workflow['configs']:
            continue
        parity = hashlib.sha256((source['id']+'|'+workflow['id']).encode()).digest()[-1] & 1
        for repeat in range(plan['repeats']):
            result.append({'slot': len(result), 'mode': plan['mode'], 'input_id': source['id'],
                'source_kind': source['kind'], 'modality': source['modality'], 'engine': engine,
                'workflow': workflow['id'], 'collection': source.get('collection', 'unspecified'),
                'repeat': repeat, 'order': 'AB' if (repeat+parity) % 2 == 0 else 'BA',
                'config_sha256': canonical_sha(workflow['configs'][engine])})
    return result


def expected_config(engine, operation, modality):
    if engine == 'pyradiomics':
        settings = {'binCount': 32} if modality == 'mr' else {'binWidth': 25.}
        if operation != 'identity':
            settings['resampledPixelSpacing'] = [1.5 if operation == 'linear_1p5' else 2.]*3
            settings['interpolator'] = 'sitkLinear' if operation == 'linear_1p5' else 'sitkBSpline'
        return {'setting': settings, 'imageType': {'Original': {}}}
    settings = {'base_feature_families': ['all'], 'base_discretisation_method': 'fixed_bin_number',
                'base_discretisation_n_bins': 32}
    if operation != 'identity':
        settings.update(new_spacing=1.5 if operation == 'linear_1p5' else 2.,
                        spline_order=1 if operation == 'linear_1p5' else 3, anti_aliasing=True)
    return settings


class Audit:
    def __init__(self, repo):
        self.repo = Path(repo).resolve()
        self.issues, self.checks, self.evidence, self.warnings = [], 0, [], []

    def check(self, condition, code, context=''):
        self.checks += 1
        if not condition:
            self.issues.append({'code': code, 'context': context})

    def public(self, relative):
        path = (self.repo/relative).resolve()
        if self.repo not in path.parents:
            raise ValueError('A public evidence pointer escaped the repository.')
        return path

    def bind(self, path, role):
        path = Path(path)
        self.evidence.append({'role': role, 'sha256': sha(path)})
        raw = path.read_text(encoding='utf-8')
        self.check(not re.search(r'(?<![A-Za-z0-9])[A-Za-z]:[\\/]|/Users/|/home/[^ /]+/', raw), 'personal_absolute_path', role)

    def plan(self, plan_path, mode):
        self.bind(plan_path, mode+'_plan')
        plan = json_read(plan_path)
        self.check(plan['mode'] == mode, 'plan_mode', mode)
        wanted_ranks = range(1, 13 if mode == 'coverage' else 5)
        wanted = {(task, rank) for task, rank in itertools.product(TASKS, wanted_ranks)}
        selected = plan['selected_inputs']
        self.check({(row['collection'], row['selection_rank']) for row in selected} == wanted and len(selected) == len(wanted),
                   'selected_rank_census', mode)
        self.check(plan['repeats'] == (1 if mode == 'coverage' else 4), 'repeat_count', mode)
        self.check(plan['warmup_pairs_per_worker'] == (0 if mode == 'coverage' else 1), 'warmup_count', mode)
        self.check(plan['native_threads'] == 1 and plan['timeout_seconds_per_pair'] == 300, 'worker_limits', mode)
        self.check(plan['intention_to_evaluate_pairs'] == (144 if mode == 'coverage' else 128), 'intention_denominator', mode)
        self.check({row['id'] for row in plan['inputs']} == {row['id'] for row in selected if row['status'] == 'prepared_and_verified'},
                   'prepared_input_census', mode)
        for item in plan['inputs']:
            source = next(row for row in selected if row['id'] == item['id'])
            self.check(all(item[key] == source[key] for key in ('collection', 'selection_rank', 'modality', 'image_sha256', 'mask_sha256')),
                       'realized_source_identity', item['id'])
        wanted_operations = ('identity', 'linear_1p5', 'cubic_2') if mode == 'coverage' else ('identity', 'cubic_2')
        self.check({row['id'] for row in plan['workflows']} == {op+'_'+mod for op, mod in itertools.product(wanted_operations, ('mr', 'ct'))},
                   'workflow_census', mode)
        for workflow in plan['workflows']:
            operation, modality = workflow['id'].rsplit('_', 1)
            self.check(workflow['modalities'] == [modality], 'workflow_modality', workflow['id'])
            for engine in ENGINES:
                self.check(workflow['configs'][engine] == expected_config(engine, operation, modality),
                           'prespecified_native_configuration', mode+'/'+engine+'/'+workflow['id'])
        provenance = plan['provenance']
        for name in ('crop_receipt', 'eligibility', 'general_freeze', 'environments'):
            path = self.public(provenance[name]['file'])
            self.check(sha(path) == provenance[name]['sha256'], 'provenance_digest', mode+'/'+name)
        receipt = json_read(self.public(provenance['crop_receipt']['file']))
        crops = {row['id']: row for row in receipt['records']}
        eligibility = json_read(self.public(provenance['eligibility']['file']))
        eligible = {(row['task'], row['selection_rank']): row for row in eligibility['records']}
        for source in selected:
            if source['status'] == 'selection_shortfall':
                self.check((source['collection'], source['selection_rank']) not in eligible, 'selection_shortfall_supported', source['id'])
                continue
            crop, origin = crops[source['id']], eligible[(source['collection'], source['selection_rank'])]
            self.check(source['status'] == crop['status'] and source['source_eligible'] == origin['source_eligible'],
                       'eligibility_and_preparation', source['id'])
            self.check(source['source_image_sha256'] == origin['image_sha256'] == crop['source_image_sha256'] and
                       source['source_mask_sha256'] == origin['mask_sha256'] == crop['source_mask_sha256'],
                       'raw_source_hash_chain', source['id'])
            if source['status'] == 'prepared_and_verified':
                self.check(crop['label'] == 1 and crop['context_mm'] == 10., 'crop_label_context', source['id'])
                self.check(crop['mask_verification']['selected_roi_completely_retained'], 'crop_support', source['id'])
                for kind in ('image', 'mask'):
                    verification = crop[kind+'_verification']
                    self.check(source[kind+'_sha256'] == crop[kind+'_sha256'] and verification['decoded_array_equal'] and
                               verification['decoded_dtype_equal'] and verification['maximum_world_error_mm'] <= 1e-4,
                               'verified_crop_hash_and_geometry', source['id']+'/'+kind)
        frozen_path = Path(plan_path).with_name(mode+'_freeze.json')
        self.bind(frozen_path, mode+'_freeze')
        frozen = json_read(frozen_path)
        self.check(frozen['plan_sha256'] == sha(plan_path), 'operational_freeze_plan_digest', mode)
        total = sum(len(expected_slots(plan, engine)) for engine in ENGINES)
        self.check(total == plan['native_planned_pairs'], 'native_planned_denominator', mode)
        self.check(plan['not_native_planned_pairs']+total == plan['intention_to_evaluate_pairs'], 'intention_partition', mode)
        return plan, frozen, sha(frozen_path)

    def exact_record(self, comparison, context):
        exact = comparison.get('native_values_unchanged')
        self.check(type(exact) is bool, 'exact_preservation_boolean', context)
        if exact:
            self.check(comparison['baseline_values'] == comparison['observed_values'], 'exact_preservation_digest_consistency', context)
            details = comparison.get('comparison_details', {})
            self.check(details.get('affected_keys', details.get('affected_column_positions', 0)) == 0,
                       'exact_preservation_difference_count', context)

    def run(self, directory, plan, frozen, frozen_sha):
        directory = Path(directory)
        metadata = json_read(directory/'run_metadata.json')
        mode, engine = metadata['mode'], metadata['engine']
        for file in ('run_metadata.json', 'planned_slots.json', 'attempt_starts.jsonl', 'cases.jsonl'):
            self.bind(directory/file, mode+'/'+engine+'/'+file)
        self.check(metadata['plan_sha256'] == frozen['plan_sha256'] and metadata['freeze_sha256'] == frozen_sha,
                   'run_frozen_identity', mode+'/'+engine)
        expected = expected_slots(plan, engine)
        self.check(json_read(directory/'planned_slots.json') == expected, 'planned_slot_identity_order', mode+'/'+engine)
        starts, records = {}, {}
        for name, target in (('attempt_starts.jsonl', starts), ('cases.jsonl', records)):
            for row in json_lines(directory/name):
                index = row['slot']
                self.check(type(index) is int and 0 <= index < len(expected) and index not in target,
                           'unique_planned_slot', mode+'/'+engine+'/'+name)
                if type(index) is not int or not 0 <= index < len(expected) or index in target:
                    continue
                self.check(all(row.get(key) == value for key, value in expected[index].items()),
                           'attempt_slot_fields', mode+'/'+engine+'/'+str(index))
                target[index] = row
        self.check(records.keys() <= starts.keys(), 'attempt_starts_cover_records', mode+'/'+engine)
        wanted_sources = {name: frozen['files'][('software/' if name.endswith('_contracts') else 'radaccord/')+name+'.py']
                          for name in ('evidence', 'operators', 'numerics', engine, 'physical_contracts', 'sampling_contracts')}
        for index, row in records.items():
            context = mode+'/'+engine+'/'+str(index)
            self.check(type(row.get('completed')) is bool, 'completion_boolean', context)
            if mode == 'timing' and row.get('warmup_comparison', {}).get('completed'):
                self.exact_record(row['warmup_comparison'], context+'/warmup')
                self.check(all(row['warmup'].get(arm, {}).get('completed') for arm in ('A', 'B')), 'warmup_arm_completion', context)
            if not row.get('completed'):
                continue
            self.exact_record(row, context)
            report = row['report']; checkpoints = report.get('checkpoints', [])
            self.check(report['checker']['source_sha256'] == wanted_sources and
                       report['checker']['implementation_sha256'] == canonical_sha(wanted_sources),
                       'checking_source_identity', context)
            self.check(report['engine'] == {'name': engine, 'version': frozen['environments'][engine]['packages'][engine]},
                       'native_engine_version', context)
            states = [checkpoint.get('status', 'unavailable') for checkpoint in checkpoints]
            overall = next((state for state in ('violated', 'unavailable', 'indeterminate') if state in states),
                           'satisfied' if states and all(value == 'satisfied' for value in states) else 'unavailable')
            self.check(report['status'] == overall, 'pair_checkpoint_status_consistency', context)
            for checkpoint in checkpoints:
                self.check(checkpoint.get('status') in STATES, 'checkpoint_state_domain', context)
                if checkpoint.get('status') != 'satisfied' and 'feature_reuse' in checkpoint:
                    self.check(checkpoint['feature_reuse'].get('decision') == 'blocked', 'unresolved_does_not_authorize_reuse', context)
            if report.get('relationship_acceptance') is True:
                self.check(report['status'] == 'satisfied' and all(check.get('coverage', {}).get('status') == 'satisfied' and
                    check.get('candidate_roi_voxels', 0) > 0 for check in checkpoints), 'accepted_relationship_obligations', context)
            if mode == 'timing':
                self.check(row.get('warmup_comparison', {}).get('completed'), 'measured_pair_has_warmup_evidence', context)
                direct, audited = row['baseline_seconds'], row['audited_seconds']
                self.check(direct > 0 and audited > 0 and math.isfinite(direct+audited), 'positive_finite_arm_times', context)
                self.check(math.isclose(row['absolute_overhead_seconds'], audited-direct, rel_tol=1e-12, abs_tol=1e-12) and
                    math.isclose(row['paired_log_ratio'], math.log(audited/direct), rel_tol=1e-12, abs_tol=1e-12), 'paired_time_arithmetic', context)
                self.check(not row.get('constructed_tasks'), 'no_timing_constructed_tasks', context)
            else:
                self.check(row.get('warmup') == {} and not any(key in row for key in METRICS[:4]), 'coverage_has_no_overhead_estimate', context)
        return metadata, expected, starts, records


def construct_summary(rows):
    tasks = [task for row in rows for task in row.get('constructed_tasks', [])]
    result = {'recorded_tasks': len(tasks), 'active_faults': sum(task['fault']['activity']['active'] for task in tasks),
              'restored_relationships': sum(task['restored_declared_relationship'] for task in tasks),
              'task_errors': sum('constructed_tasks_error' in row for row in rows), 'comparators': {}}
    for comparator in ('paired_geometry', 'source_aware_geometry', 'radaccord'):
        result['comparators'][comparator] = {condition: {state: sum(task[condition][comparator]['status'] == state for task in tasks)
            for state in STATES} for condition in ('valid_control', 'fault', 'correction')}
    return result


def recompute(audit, plans, runs):
    groups, volumes, constructed, clinical_limits, constructed_detection = [], [], [], [], []
    for mode, engine, collection in itertools.product(MODES, ENGINES, TASKS):
        plan = plans[mode]
        metadata, expected, starts, records = runs[(mode, engine)]
        selected = [row for row in plan['selected_inputs'] if row['collection'] == collection]
        modality = TASKS[collection]
        for workflow in (row for row in plan['workflows'] if modality in row['modalities']):
            intended = [row for row in expected if row['collection'] == collection and row['workflow'] == workflow['id']]
            observed = [records[row['slot']] for row in intended if row['slot'] in records]
            complete = [row for row in observed if row.get('completed')]
            attempted = sum(row['slot'] in starts for row in intended)
            grouping = {'mode': mode, 'collection': collection, 'workflow': workflow['id'], 'engine': engine}
            group = {**grouping, 'selected_volume_slots': len(selected),
                'source_eligible_volume_slots': sum(row['source_eligible'] for row in selected),
                'prepared_volume_slots': sum(row['status'] == 'prepared_and_verified' for row in selected),
                'intention_to_evaluate_pairs': len(selected)*plan['repeats'], 'native_planned_pairs': len(intended),
                'not_native_planned_pairs': len(selected)*plan['repeats']-len(intended),
                'attempted_pairs': attempted, 'recorded_pairs': len(observed), 'completed_pairs': len(complete),
                'exact_preservation_pairs': sum(row['native_values_unchanged'] for row in complete),
                'failed_recorded_pairs': len(observed)-len(complete), 'started_without_record_pairs': attempted-len(observed),
                'unstarted_pairs': len(intended)-attempted,
                'source_or_preparation_outcomes': dict(sorted(Counter(row['status'] for row in selected).items())),
                'relationship_outcomes': {state: sum(row['report']['status'] == state for row in complete) for state in STATES}}
            checkpoints = [checkpoint for row in complete for checkpoint in row['report'].get('checkpoints', [])]
            group['checkpoint_count'] = len(checkpoints)
            group['checkpoint_outcomes'] = {state: sum(row.get('status') == state for row in checkpoints) for state in STATES}
            group['reported_coverage_obligations'] = dict(sorted(Counter(row['coverage'].get('status', 'unavailable')
                for row in checkpoints if 'coverage' in row).items()))
            group['reported_reuse_obligations'] = dict(sorted(Counter(row['feature_reuse'].get('decision', 'unavailable')
                for row in checkpoints if 'feature_reuse' in row).items()))
            if mode == 'timing':
                warmups = [row['warmup_comparison'] for row in observed if row.get('warmup_comparison', {}).get('completed')]
                group['warmup_pairs_completed'] = len(warmups)
                group['warmup_exact_preservation_pairs'] = sum(row['native_values_unchanged'] for row in warmups)
            local = []
            for input_id in sorted({row['input_id'] for row in observed}):
                source_rows = [row for row in observed if row['input_id'] == input_id]
                finished = [row for row in source_rows if row.get('completed')]
                volume = {'mode': mode, 'collection': collection, 'engine': engine, 'workflow': workflow['id'],
                    'input_id': input_id, 'planned': len(source_rows), 'completed': len(finished),
                    'unchanged': sum(row['native_values_unchanged'] for row in finished),
                    'orders': dict(Counter({order: sum(row['order'] == order for row in source_rows) for order in ('AB', 'BA')})),
                    'relationship_outcomes': {state: sum(row['report']['status'] == state for row in finished) for state in STATES}}
                if mode == 'timing':
                    for metric in METRICS[:4]:
                        volume[metric] = describe(row[metric] for row in finished)
                volume['pair_lifetime_peak_bytes'] = describe(row.get('pair_peak_memory_after', {}).get('bytes') for row in finished)
                intended_source_repeats = sum(row['input_id'] == input_id for row in intended)
                if len(source_rows) != intended_source_repeats:
                    audit.warnings.append({'code': 'volume_summary_planned_field_counts_recorded_attempts',
                        'context': mode+'/'+engine+'/'+input_id+'/'+workflow['id'],
                        'recorded_attempts': len(source_rows), 'full_planned_repeats': intended_source_repeats})
                volumes.append(volume); local.append(volume)
            if mode == 'timing':
                group['volume_medians'] = {metric: describe((row[metric]['median'] for row in local), include_range=True) for metric in METRICS}
            audit.check(sum(group['relationship_outcomes'].values()) == group['completed_pairs'], 'complete_state_partition', str(tuple(grouping.values())))
            audit.check(group['completed_pairs']+group['failed_recorded_pairs']+group['started_without_record_pairs']+
                        group['unstarted_pairs']+group['not_native_planned_pairs'] == group['intention_to_evaluate_pairs'],
                        'full_intention_partition', str(tuple(grouping.values())))
            unresolved = sum(group['relationship_outcomes'][state] for state in ('indeterminate', 'unavailable'))
            clinical_limits.append({**grouping, 'completed_pairs': len(complete), 'unresolved_relationships': unresolved,
                'unresolved_fraction_of_completed': unresolved/len(complete) if complete else None,
                'scope': 'Uncertainty/applicability accounting; no population confidence interval or clinical-utility claim.'})
            groups.append(group)
        if mode == 'coverage':
            rows = [row for row in records.values() if row['collection'] == collection]
            all_tasks = []
            for row in rows:
                tasks = row.get('constructed_tasks', [])
                all_tasks.extend(tasks)
                if tasks:
                    audit.check(len(tasks) == 2 and {task['mechanism'] for task in tasks} ==
                        {'shared_origin_shift', 'decoded_intensity_offset'}, 'constructed_mechanism_census', engine+'/'+row['input_id'])
                    earliest = min(value['slot'] for value in expected if value['input_id'] == row['input_id'])
                    audit.check(row['slot'] == earliest, 'constructed_tasks_once_at_first_source_slot', engine+'/'+row['input_id'])
                for task in tasks:
                    ctx = engine+'/'+row['input_id']+'/'+task['mechanism']
                    audit.check(task['case_kind'] == 'constructed_failure_and_declared_correction', 'constructed_case_role', ctx)
                    audit.check(task['restored_declared_relationship'] == (task['correction']['radaccord']['status'] == 'satisfied'),
                                'recorded_correction_decision', ctx)
                    audit.check(task['source']['frame_sha256'] == task['correction']['candidate']['frame_sha256'], 'restoration_source_hash', ctx)
                    activity = task['fault']['activity']
                    independently_active = (activity['max_changed_intensity'] > 1e-4 or activity['changed_roi_voxels'] > 0 or
                                            activity['max_changed_header_displacement_mm'] > 1e-4)
                    audit.check(activity['active'] == independently_active, 'constructed_activity_arithmetic', ctx)
                    if not task['fault']['activity']['active']:
                        audit.warnings.append({'code': 'inactive_constructed_fault', 'context': ctx})
            task_summary = construct_summary(rows)
            constructed.append({'mode': mode, 'engine': engine, 'collection': collection,
                'intention_to_evaluate_tasks': len(selected)*2,
                'prepared_source_tasks': 2*sum(row['status'] == 'prepared_and_verified' for row in selected), **task_summary})
            active = [task for task in all_tasks if task['fault']['activity']['active']]
            constructed_detection.append({'mode': mode, 'engine': engine, 'collection': collection,
                'recorded_tasks': len(all_tasks), 'active_faults': len(active),
                'active_detected_faults': {comparator: sum(task['fault'][comparator]['status'] == 'violated' for task in active)
                    for comparator in ('paired_geometry', 'source_aware_geometry', 'radaccord')},
                'satisfied_valid_controls': sum(task['valid_control']['radaccord']['status'] == 'satisfied' for task in all_tasks),
                'satisfied_corrections': sum(task['correction']['radaccord']['status'] == 'satisfied' for task in all_tasks),
                'scope': 'Conditional detection among active constructed faults, separately by engine; no spontaneous incidence estimate.'})
    return {'groups': groups, 'volume_summaries': volumes, 'constructed_tasks': constructed,
            'uncertainty_accounting': clinical_limits, 'constructed_detection': constructed_detection}


def keyed(rows, fields):
    return {tuple(row[field] for field in fields): row for row in rows}


def compare(audit, expected, actual, location):
    if isinstance(expected, dict):
        audit.check(isinstance(actual, dict) and expected.keys() == actual.keys(), 'aggregate_fields', location)
        if isinstance(actual, dict):
            for key in expected.keys() & actual.keys():
                compare(audit, expected[key], actual[key], location+'/'+str(key))
    elif isinstance(expected, list):
        audit.check(isinstance(actual, list) and len(actual) == len(expected), 'aggregate_list_length', location)
        if isinstance(actual, list):
            for index, (left, right) in enumerate(zip(expected, actual)):
                compare(audit, left, right, location+'/'+str(index))
    elif isinstance(expected, float):
        audit.check(isinstance(actual, (int, float)) and math.isclose(expected, actual, rel_tol=1e-12, abs_tol=1e-12),
                    'aggregate_numerical_value', location)
    else:
        audit.check(type(actual) is type(expected) and actual == expected, 'aggregate_exact_value', location)


def perform(repo, plan_dir, run_paths, aggregate, output):
    audit = Audit(repo)
    required = [Path(plan_dir)/(mode+suffix+'.json') for mode, suffix in itertools.product(MODES, ('_plan', '_freeze'))]
    required += [Path(directory)/name for directory in run_paths.values()
                 for name in ('run_metadata.json', 'planned_slots.json', 'attempt_starts.jsonl', 'cases.jsonl')]
    if not all(path.is_file() for path in required):
        return {'status': 'pending', 'missing_required_files': sum(not path.is_file() for path in required),
                'verdict': 'La auditoría está preparada; faltan planes o ledgers de resultados. No se ha evaluado evidencia clínica.'}
    plans, freezes, frozen_hashes = {}, {}, {}
    for mode in MODES:
        plans[mode], freezes[mode], frozen_hashes[mode] = audit.plan(Path(plan_dir)/(mode+'_plan.json'), mode)
    expected_timing = {row['id']: row for row in plans['coverage']['inputs'] if row['selection_rank'] <= 4}
    audit.check({row['id']: row for row in plans['timing']['inputs']} == expected_timing,
                'timing_preserves_fixed_coverage_subset_and_hashes')
    runs = {key: audit.run(directory, plans[key[0]], freezes[key[0]], frozen_hashes[key[0]]) for key, directory in run_paths.items()}
    result = recompute(audit, plans, runs)
    for mode in MODES:
        groups = [row for row in result['groups'] if row['mode'] == mode]
        audit.check(sum(row['intention_to_evaluate_pairs'] for row in groups) == (144 if mode == 'coverage' else 128),
                    'global_intention_denominator', mode)
    compared = Path(aggregate).is_file()
    if compared:
        audit.bind(aggregate, 'prespecified_aggregate')
        actual = json_read(aggregate)
        for component, keys in (('groups', ('mode', 'collection', 'workflow', 'engine')),
                                ('volume_summaries', ('mode', 'collection', 'workflow', 'engine', 'input_id')),
                                ('constructed_tasks', ('mode', 'collection', 'engine'))):
            expected_rows, actual_rows = keyed(result[component], keys), keyed(actual[component], keys)
            audit.check(len(actual_rows) == len(actual[component]), 'aggregate_duplicate_groups', component)
            audit.check(expected_rows.keys() == actual_rows.keys(), 'aggregate_group_census', component)
            for key in expected_rows.keys() & actual_rows.keys():
                compare(audit, expected_rows[key], actual_rows[key], component+'/'+str(key))
    status = 'failed' if audit.issues else 'passed' if compared else 'awaiting_aggregate'
    verdict = ('La contabilidad independiente coincide con los resultados y el agregado preespecificado; conserva exclusiones, incertidumbre y fallos.'
               if status == 'passed' else 'Se han detectado discrepancias que requieren revisión antes de interpretar los resultados.'
               if status == 'failed' else 'La recontabilidad independiente está completa; queda compararla con el agregado final.')
    report = {'schema_version': 'independent-prospective-audit-1', 'status': status, 'aggregate_compared': compared,
        'checks': audit.checks, 'issues': audit.issues, 'warnings': audit.warnings, 'evidence': audit.evidence,
        'audit_script_sha256': sha(__file__), 'verdict': verdict, 'recomputed': result,
        'scope': 'Independent implementation of record accounting and arithmetic, using Python standard library only. No image reading, producer execution, independent recovery of private native feature values, or external-user validation.',
        'limitations': ['Repeated operations and two engine observations are not independent patients or incidents.',
                       'Peak working set is process lifetime memory, not incremental audit memory.',
                       'Exact-output evidence is checked for consistency, not regenerated from private native values.',
                       'Constructed corrections do not estimate spontaneous errors, human review benefit or clinical outcomes.']}
    output = Path(output)
    with output.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(report, stream, indent=2, sort_keys=True, allow_nan=False); stream.write('\n')
    output.with_suffix('.md').write_text(verdict+'\n\n'+report['scope']+'\n', encoding='utf-8')
    return report


def self_test():
    assert describe([1, 2, 3, 4]) == {'n': 4, 'median': 2.5, 'q1': 1.75, 'q3': 3.25}
    assert describe([describe([1, 1, 1, 1])['median'], describe([9])['median']], True)['median'] == 5
    assert describe([1, 1, 1, 1, 9])['median'] == 1
    plan = {'mode': 'timing', 'repeats': 4, 'inputs': [{'id': task+str(rank), 'kind': 'image', 'modality': modality,
            'collection': task} for task, modality in TASKS.items() for rank in range(1, 5)],
            'workflows': [{'id': op+'_'+modality, 'modalities': [modality],
                           'configs': {engine: expected_config(engine, op, modality) for engine in ENGINES}}
                          for modality, op in itertools.product(('mr', 'ct'), ('identity', 'cubic_2'))]}
    slots = [row for engine in ENGINES for row in expected_slots(plan, engine)]
    assert len(slots) == 128
    partitions = defaultdict(list)
    for row in slots:
        partitions[(row['engine'], row['input_id'], row['workflow'])].append(row['order'])
    assert all(Counter(orders) == {'AB': 2, 'BA': 2} for orders in partitions.values())
    audit = Audit(BASE/'RadAccord')
    compare(audit, {'median': .1+.2, 'n': 2}, {'median': .3, 'n': 2}, 'synthetic')
    assert not audit.issues
    compare(audit, {'n': 2}, {'n': 3}, 'synthetic_tamper')
    assert audit.issues[-1]['code'] == 'aggregate_exact_value'
    return {'status': 'self_test_passed', 'scope': 'Synthetic arithmetic/order fixtures; no clinical records or images read.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=BASE/'RadAccord')
    parser.add_argument('--plan-dir', type=Path)
    parser.add_argument('--run', action='append', default=[], help='mode:engine=DIRECTORY, once per four combinations')
    parser.add_argument('--aggregate', type=Path)
    parser.add_argument('--output', type=Path, default=BASE/'work/independent_prospective_audit.json')
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        print(json.dumps(self_test())); return
    runs = {(mode, engine): args.repo/'results'/('prospective_'+mode)/engine for mode, engine in itertools.product(MODES, ENGINES)}
    for entry in args.run:
        name, location = entry.split('=', 1); key = tuple(name.split(':'))
        if key not in runs:
            raise ValueError('Unknown mode/engine run key.')
        runs[key] = Path(location)
    result = perform(args.repo, args.plan_dir or args.repo/'protocol/prospective_operational', runs,
                     args.aggregate or args.repo/'results/prospective_aggregate.json', args.output)
    print(json.dumps({key: result[key] for key in ('status', 'verdict')}, ensure_ascii=False))
    if result['status'] == 'failed':
        raise SystemExit(1)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print(json.dumps({'status': 'audit_execution_failed', 'exception_type': type(error).__name__}))
        raise SystemExit(2)
