# Native refinement evidence: rc2

This immutable snapshot preserves the 27 files frozen before the native refinement evaluation, the full 62-pair plan for each engine, all 124 original records, and their eight summary files. This is calibration-informed reevaluation on reused inputs, not independent clinical validation. No raw clinical images, private source paths or credentials are included.

The native evaluation used the environments in protocol/native_refinement_freeze.json. Clinical images must be obtained separately under their original release terms; this archive permits summary reproduction without those images or the native extractors.

The inherited frozen summarizer expected five checking-source hashes. A separately hash-bound analysis correction includes the sixth (numerics), without modifying any frozen inference, threshold, source, configuration or raw record. See protocol/native_refinement_analysis.json. This correction was recorded after native evaluation began and before the archived refinement records were summarized.

From this archive root, with Python 3.10 or later:

```sh
python -B -m unittest scripts.tests.test_native_refinement_summary
python -B scripts/summarize_native_refinement.py --run results/native_refinement/mirp --run results/native_refinement/pyradiomics --freeze protocol/native_refinement_freeze.json --out reproduced_summary
```

The summarizer verifies the 27-source freeze, the analysis correction, plan IDs, raw record and run-summary hashes, and all six checking implementation hashes. It refuses to overwrite derivatives. Compare the eight generated files to results/native_refinement/summary; no native extraction is performed. MANIFEST.sha256 covers every payload byte.

Native features are returned unchanged; this is not evidence of feature correctness, clinical validity or cross-engine equivalence. Pair completion, checkpoint status, coverage and reuse decisions have distinct denominators. Timings are descriptive because baseline extraction always preceded the observed extraction.

A later rc3 command-line Path-to-string correction is outside this rc2 snapshot and does not retrospectively alter the evaluation.
