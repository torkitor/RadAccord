# RadAccord native calibration 1: immutable original execution

This snapshot preserves the first development evaluation of native integration,
using the original 1.2.0rc1 checking profiles. Fifteen implementation/protocol/test
files are byte-identical to the internal pre-evaluation freeze of 2026-09-09
12:13:58 UTC. The original protocol text and all first-run records remain
unchanged. Later numerical refinement, amendments and validation belong to
separate records and must not replace this snapshot.

## Retained results and denominators

- MIRP: 62 planned pairs, 62 recorded attempts, 61 completed pairs. All 61
  completed pairs preserved native values exactly. Pair outcomes: 54 satisfied,
  five violated, two unavailable; one additional attempt has a recorded failure.
- PyRadiomics: 62 planned pairs, 51 complete recorded attempts. All 51 preserved
  native values exactly. Pair outcomes: 48 satisfied, two violated, one
  indeterminate. The process ended without its final run summary. The next
  scheduled slot (hippocampus_193, identity; ordinal 52) has no stored result;
  its start/completion are unknown. Ten later slots were not reached. The cause
  of interruption is undetermined; no out-of-memory diagnosis is asserted.
- The summaries account for 124 planned slots, 113 case records, 112 completed
  pairs and 214 recorded checkpoints. No feature values, timing or checkpoint
  results have been fabricated for the eleven unrecorded PyRadiomics slots.

These numerical alerts made this a first development/calibration evaluation,
not evidence that the initial profile universally passes valid native pipelines.
This is not an independent clinical cohort: the public volumes were previously
used in the sampling study, and input IDs do not prove independent patients.
Label 1 is selected here, unlike the earlier union-of-positive-label sampling
experiment. Baseline runs precede audited runs; timings are descriptive and do
not establish a causal overhead multiplier. MIRP numeric columns include metadata
and are not counts of radiomic features. Native-value preservation does not
establish measurement correctness or clinical validity.

## Reproduce the archived summary without clinical images

From this extracted folder, with Python 3.10 or later:

    python -B scripts/verify_native_freeze.py
    python -B -m unittest discover -s scripts/tests -p test_native_summary.py
    python -B -m scripts.summarize_native_study --run results/native_integration/mirp --run results/native_integration/pyradiomics --out reproduced_summary

The summary uses only the standard library, validates the frozen code and plan,
checks case-file hashes, and verifies complete or explicitly interrupted planned
ledgers. The eight regenerated files should be byte-identical to
results/native_integration/summary_first_development/. The summarizer and eight
integrity tests were written after the evaluation to summarize its stored
records; they are not part of the original fifteen-file scientific freeze.

Re-running native extraction requires the respective environments and external
public Medical Segmentation Decathlon downloads. See protocol/native_study.md
and protocol/native_study_plan.json for exact inputs, hashes and processing
settings. No clinical images, temporary files, local paths, caches or private
logs are included. Native executions are not rerun by summary reproduction.

## Archive integrity

MANIFEST.sha256 covers every archive payload except itself, with paths relative
to this folder. On systems providing sha256sum, run `sha256sum -c MANIFEST.sha256`.
The archive has sorted members, fixed timestamps and permissions. Its SHA-256 is
recorded separately because a ZIP cannot include its own final hash. The native
freeze remains the binding for the original fifteen-file payload; MANIFEST also
covers records, derivative summaries and documentation.
