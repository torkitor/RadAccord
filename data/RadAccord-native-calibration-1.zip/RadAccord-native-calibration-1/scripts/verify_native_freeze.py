"""Verify the immutable native-study payload before interpreting its results."""
import hashlib
import json
from pathlib import Path


def verify(root):
    root = Path(root)
    freeze = json.loads((root/'protocol/native_freeze.json').read_text(encoding='utf-8'))
    failures = [name for name, digest in freeze['files'].items()
                if not (root/name).is_file() or hashlib.sha256((root/name).read_bytes()).hexdigest() != digest]
    if failures:
        raise ValueError('Native study freeze mismatch: '+', '.join(failures))
    return len(freeze['files'])


if __name__ == '__main__':
    count = verify(Path(__file__).resolve().parents[1])
    print(f'Native study freeze verified: {count} files.')
